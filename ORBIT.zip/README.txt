ORBIT - Android project (crosshair overlay, device profile, latency lab, optimizer, history)

APK banane ke 2 tareeke
=======================

A) GitHub se (laptop ya Android Studio nahi chahiye)
  1. github.com par naya repo banao (Private theek hai).
  2. Is zip ko extract karke andar ki saari files repo me upload karo
     (".github/workflows/build.yml" bhi, folder structure same rehna chahiye).
     Phone par folder upload mushkil ho to: ORBIT.zip ko hi repo me upload karo,
     aur "Add file > Create new file" me naam likho  .github/workflows/build.yml
     aur chat wala workflow text paste karo.
  3. Repo me "Actions" tab kholo > "Build APK" > Run workflow (ya bas push karo, apne aap chalega).
  4. 5-8 minute baad run khologe to neeche "Artifacts" me  ORBIT-debug-apk  milega. Download karo,
     zip kholo, andar app-debug.apk hai. Phone me install karo (Unknown sources allow karna padega).

B) Android Studio
  1. Is folder ko "Open" karo. Gradle sync hone do (AGP 8.5.2, Kotlin 1.9.24, JDK 17).
  2. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk

Pehli baar app chalane par
==========================
- Crosshair > Start dabao > "Display over other apps" allow karo.
- Notifications allow karo (service notification ke liye).
- Auto-show (game ke khulte hi) ke liye "Usage access" allow karna padega.

Build fail ho to Actions me red run kholo, error ka text copy karke bhej do.
