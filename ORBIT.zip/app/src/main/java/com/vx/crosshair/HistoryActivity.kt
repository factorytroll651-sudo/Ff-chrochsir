package com.vx.crosshair

import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class HistoryActivity : AppCompatActivity() {

    private lateinit var list: ListView
    private var items: List<HistoryEntry> = emptyList()
    private val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())

    // metrics where a bigger number is the better result
    private val higherBetter = setOf("hz")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(makeButton("Compare profiles") { compare("profile") }, weighted())
        row.addView(makeButton("Compare latency") { compare("latency") }, weighted())
        row.addView(makeButton("Clear all") { confirmClear() }, weighted())

        list = ListView(this)
        val hint = TextView(this)
        hint.text = "Tap: details. Long-press: delete."
        hint.textSize = 12f

        root.addView(row)
        root.addView(hint)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos < items.size) {
                val e = items[pos]
                AlertDialog.Builder(this).setTitle(e.title).setMessage(e.text)
                    .setPositiveButton("Close", null).show()
            }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < items.size) {
                val e = items[pos]
                AlertDialog.Builder(this).setTitle("Delete this entry?")
                    .setPositiveButton("Delete") { _, _ ->
                        HistoryStore.delete(this, e.ts)
                        refresh()
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            true
        }
    }

    private fun weighted() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun makeButton(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 11f
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        items = HistoryStore.all(this)
        val labels = items.map { "${fmt.format(Date(it.ts))}   [${it.type}]   ${it.title}" }
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            if (labels.isEmpty()) listOf("No saved results yet") else labels
        )
    }

    private fun compare(type: String) {
        val l = HistoryStore.all(this).filter { it.type == type }
        if (l.size < 2) {
            Toast.makeText(this, "Need two saved $type results", Toast.LENGTH_SHORT).show()
            return
        }
        val now = l[0]
        val old = l[1]
        val sb = StringBuilder("Older: ${fmt.format(Date(old.ts))}\nNewer: ${fmt.format(Date(now.ts))}\n\n")
        now.metrics.keys.filter { old.metrics.containsKey(it) }.sorted().forEach { k ->
            val a = old.metrics.getValue(k)
            val n = now.metrics.getValue(k)
            val delta = n - a
            val good = if (k in higherBetter) delta > 0 else delta < 0
            val verdict = when {
                abs(delta) < 1e-9 -> "same"
                good -> "better"
                else -> "worse"
            }
            sb.appendLine("$k: ${"%.2f".format(a)} -> ${"%.2f".format(n)}  (${"%+.2f".format(delta)}, $verdict)")
        }
        AlertDialog.Builder(this).setTitle("Before / after").setMessage(sb.toString())
            .setPositiveButton("Close", null).show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setTitle("Delete all history?")
            .setPositiveButton("Delete") { _, _ ->
                HistoryStore.clear(this)
                refresh()
            }
            .setNegativeButton("Cancel", null).show()
    }
}
