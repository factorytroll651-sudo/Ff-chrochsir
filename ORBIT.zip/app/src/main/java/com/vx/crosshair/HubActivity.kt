package com.vx.crosshair

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

class HubActivity : AppCompatActivity() {

    private data class Entry(val id: String, val label: String, val target: Class<*>)

    private val entries = listOf(
        Entry("crosshair", "Crosshair", MainActivity::class.java),
        Entry("profile", "Device profile", ProfileActivity::class.java),
        Entry("latency", "Latency lab", LatencyActivity::class.java),
        Entry("optimizer", "Optimizer", OptimizerActivity::class.java),
        Entry("history", "History", HistoryActivity::class.java)
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        // codename block
        val vm = VmCheck.run(this)
        val block = LinearLayout(this)
        block.orientation = LinearLayout.VERTICAL
        block.setBackgroundColor(Color.parseColor("#1B2230"))
        block.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "ORBIT"
        title.textSize = 34f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        block.addView(title)

        val sub = TextView(this)
        sub.text = "Crosshair + Profile + Latency + Optimizer  |  v1.0"
        sub.textSize = 12f
        sub.setTextColor(Color.LTGRAY)
        block.addView(sub)

        val env = TextView(this)
        env.text = "Environment: ${vm.label} (VMness ${vm.score}/100)"
        env.textSize = 13f
        env.setTextColor(Color.parseColor("#00E676"))
        env.setPadding(0, pad / 2, 0, 0)
        block.addView(env)

        root.addView(block, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        // shortcut block
        val label = TextView(this)
        label.text = "Shortcuts"
        label.textSize = 16f
        label.setPadding(0, pad, 0, pad / 2)
        root.addView(label)

        val grid = GridLayout(this)
        grid.columnCount = 2
        entries.forEach { e ->
            val btn = Button(this)
            btn.text = e.label
            btn.setOnClickListener { startActivity(Intent(this, e.target)) }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            lp.width = 0
            lp.setGravity(Gravity.FILL_HORIZONTAL)
            grid.addView(btn, lp)
        }
        root.addView(grid, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
        publishShortcuts(this)
    }

    private fun publishShortcuts(ctx: Context) {
        try {
            val list = entries.take(4).map { e ->
                ShortcutInfoCompat.Builder(ctx, e.id)
                    .setShortLabel(e.label)
                    .setIcon(IconCompat.createWithResource(ctx, R.drawable.ic_tile))
                    .setIntent(Intent(ctx, e.target).setAction(Intent.ACTION_VIEW))
                    .build()
            }
            ShortcutManagerCompat.setDynamicShortcuts(ctx, list)
        } catch (_: Exception) { }
    }
}
