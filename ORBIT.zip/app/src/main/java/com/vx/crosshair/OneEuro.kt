package com.vx.crosshair

import kotlin.math.PI
import kotlin.math.abs

class OneEuro(var minCutoff: Double = 1.0, var beta: Double = 0.01, private val dCutoff: Double = 1.0) {

    private var xPrev = Double.NaN
    private var dxPrev = 0.0
    private var tPrev = 0L

    fun reset() {
        xPrev = Double.NaN
        dxPrev = 0.0
        tPrev = 0L
    }

    private fun alpha(cutoff: Double, dtSec: Double): Double {
        val tau = 1.0 / (2.0 * PI * cutoff)
        return 1.0 / (1.0 + tau / dtSec)
    }

    fun filter(x: Double, tMs: Long): Double {
        if (xPrev.isNaN()) {
            xPrev = x
            tPrev = tMs
            return x
        }
        val dt = ((tMs - tPrev).coerceAtLeast(1L)) / 1000.0
        val dx = (x - xPrev) / dt
        val aD = alpha(dCutoff, dt)
        val edx = aD * dx + (1 - aD) * dxPrev
        val cutoff = minCutoff + beta * abs(edx)
        val a = alpha(cutoff, dt)
        val xHat = a * x + (1 - a) * xPrev
        xPrev = xHat
        dxPrev = edx
        tPrev = tMs
        return xHat
    }
}
