package com.vx.crosshair

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.view.Choreographer
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class ProfileActivity : AppCompatActivity() {

    private lateinit var out: TextView
    private lateinit var run: Button
    private lateinit var copy: Button
    private var lastReport = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        run = Button(this)
        run.text = "Run profile"
        copy = Button(this)
        copy.text = "Copy report"
        copy.isEnabled = false
        out = TextView(this)
        out.text = "Keep the phone still and unplugged, then tap Run profile (about 5 s)."
        out.setTextIsSelectable(true)

        root.addView(run, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(copy, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(out)
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        run.setOnClickListener { start() }
        copy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("profile", lastReport))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun start() {
        run.isEnabled = false
        copy.isEnabled = false
        out.text = "Measuring CPU..."
        val profile = Profiler.collect(this)

        thread(name = "cpu-bench") {
            val ms = try { Profiler.cpuBenchmarkMs() } catch (e: Exception) { -1L }
            profile.cpuMs = ms
            runOnUiThread {
                out.text = "Measuring frame stability..."
                frameTest(profile)
            }
        }
    }

    private fun frameTest(profile: DeviceProfile) {
        val target = 120
        val deltas = ArrayList<Double>(target)
        var last = 0L
        val ch = Choreographer.getInstance()
        val vsyncMs = 1000.0 / profile.refreshHz.coerceAtLeast(30f)

        val cb = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (last != 0L) deltas += (frameTimeNanos - last) / 1_000_000.0
                last = frameTimeNanos
                if (deltas.size < target) ch.postFrameCallback(this)
                else onTestDone(profile, deltas, vsyncMs)
            }
        }
        ch.postFrameCallback(cb)
    }

    private fun onTestDone(p: DeviceProfile, d: List<Double>, vsyncMs: Double) {
        if (d.isNotEmpty()) {
            p.avgFrameMs = d.average()
            p.jankPct = d.count { it > vsyncMs * 1.5 } * 100.0 / d.size
        }
        lastReport = Recommender.report(p)
        out.text = lastReport
        HistoryStore.add(
            this, "profile", "Profile - ${Recommender.tier(p)}", lastReport,
            mapOf("cpuMs" to p.cpuMs.toDouble(), "avgFrameMs" to p.avgFrameMs, "jankPct" to p.jankPct)
        )
        run.isEnabled = true
        copy.isEnabled = true
    }
}
