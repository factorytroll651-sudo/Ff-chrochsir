package com.vx.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.os.SystemClock
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.sqrt

/** Test pad that lives only inside this app. It measures touch timing and shows a smoothing filter on its own trail. */
class TouchPadView(ctx: Context) : View(ctx) {

    data class Stats(
        val samples: Int,
        val hz: Double,
        val dtAvg: Double, val dtP95: Double, val dtMax: Double,
        val deliveryAvg: Double, val deliveryP95: Double,
        val frameAvg: Double, val frameP95: Double,
        val rawJitter: Double, val smoothJitter: Double, val lagPx: Double
    )

    private val maxPoints = 600
    private val maxStats = 3000

    private val raw = ArrayList<PointF>()
    private val smooth = ArrayList<PointF>()
    private val dts = ArrayList<Double>()
    private val delivery = ArrayList<Double>()
    private val frameLat = ArrayList<Double>()
    private val pending = ArrayList<Long>()

    val fx = OneEuro()
    val fy = OneEuro()
    private var lastT = -1L
    private var running = false

    private val pRaw = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF5252"); strokeWidth = 4f; style = Paint.Style.STROKE
    }
    private val pSmooth = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); strokeWidth = 4f; style = Paint.Style.STROKE
    }
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = 36f }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            val fm = frameTimeNanos / 1_000_000.0
            if (pending.isNotEmpty()) {
                for (t in pending) frameLat.add((fm - t.toDouble()).coerceAtLeast(0.0))
                pending.clear()
                while (frameLat.size > maxStats) frameLat.removeAt(0)
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    init { setBackgroundColor(Color.parseColor("#14181F")) }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    private fun handle(x: Float, y: Float, t: Long) {
        if (lastT >= 0 && t > lastT) {
            dts.add((t - lastT).toDouble())
            while (dts.size > maxStats) dts.removeAt(0)
        }
        lastT = t
        raw.add(PointF(x, y))
        smooth.add(PointF(fx.filter(x.toDouble(), t).toFloat(), fy.filter(y.toDouble(), t).toFloat()))
        pending.add(t)
        while (raw.size > maxPoints) {
            raw.removeAt(0)
            smooth.removeAt(0)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            fx.reset(); fy.reset(); lastT = -1L
            raw.clear(); smooth.clear()
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            delivery.add((SystemClock.uptimeMillis() - e.eventTime).toDouble().coerceAtLeast(0.0))
            while (delivery.size > maxStats) delivery.removeAt(0)
            for (h in 0 until e.historySize)
                handle(e.getHistoricalX(h), e.getHistoricalY(h), e.getHistoricalEventTime(h))
            handle(e.x, e.y, e.eventTime)
            invalidate()
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawText("Draw here. Red = raw, green = smoothed", 24f, 52f, pText)
        for (i in 1 until raw.size) {
            c.drawLine(raw[i - 1].x, raw[i - 1].y, raw[i].x, raw[i].y, pRaw)
            c.drawLine(smooth[i - 1].x, smooth[i - 1].y, smooth[i].x, smooth[i].y, pSmooth)
        }
    }

    fun clear() {
        raw.clear(); smooth.clear(); dts.clear(); delivery.clear(); frameLat.clear(); pending.clear()
        fx.reset(); fy.reset(); lastT = -1L
        invalidate()
    }

    private fun mean(l: List<Double>) = if (l.isEmpty()) 0.0 else l.average()

    private fun p95(l: List<Double>): Double {
        if (l.isEmpty()) return 0.0
        val s = l.sorted()
        return s[((s.size - 1) * 0.95).toInt()]
    }

    private fun jitter(p: List<PointF>): Double {
        if (p.size < 3) return 0.0
        var sum = 0.0
        for (i in 1 until p.size - 1) {
            val ax = p[i + 1].x - 2 * p[i].x + p[i - 1].x
            val ay = p[i + 1].y - 2 * p[i].y + p[i - 1].y
            sum += (ax * ax + ay * ay).toDouble()
        }
        return sqrt(sum / (p.size - 2))
    }

    fun stats(): Stats {
        val n = minOf(raw.size, smooth.size)
        var lag = 0.0
        for (i in 0 until n) lag += hypot(
            (raw[i].x - smooth[i].x).toDouble(), (raw[i].y - smooth[i].y).toDouble()
        )
        val avgDt = mean(dts)
        return Stats(
            samples = raw.size,
            hz = if (avgDt > 0) 1000.0 / avgDt else 0.0,
            dtAvg = avgDt, dtP95 = p95(dts), dtMax = dts.maxOrNull() ?: 0.0,
            deliveryAvg = mean(delivery), deliveryP95 = p95(delivery),
            frameAvg = mean(frameLat), frameP95 = p95(frameLat),
            rawJitter = jitter(raw), smoothJitter = jitter(smooth),
            lagPx = if (n > 0) lag / n else 0.0
        )
    }
}
