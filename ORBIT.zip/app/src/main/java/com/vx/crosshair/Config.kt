package com.vx.crosshair

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Config(
    var style: Int = 0,
    var sizeDp: Int = 60,
    var thicknessDp: Int = 3,
    var gapDp: Int = 6,
    var opacity: Int = 90,
    var rotation: Int = 0,
    var color: Int = 0xFFFF2D2D.toInt(),
    var dot: Boolean = true,
    var dotSizeDp: Int = 3,
    var outline: Boolean = true,
    var glow: Boolean = false,
    var locked: Boolean = false,
    var x: Int = 0,
    var y: Int = 0,
    var imagePath: String = "",
    var miniButton: Boolean = false,
    var autoPkg: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("style", style); put("size", sizeDp); put("thick", thicknessDp)
        put("gap", gapDp); put("opacity", opacity); put("rot", rotation)
        put("color", color); put("dot", dot); put("dotSize", dotSizeDp)
        put("outline", outline); put("glow", glow); put("locked", locked)
        put("x", x); put("y", y); put("img", imagePath)
        put("mini", miniButton); put("auto", autoPkg)
    }

    companion object {
        val STYLE_NAMES = listOf(
            "Plus", "Plus + gap", "Circle", "Circle + dot",
            "Cross X", "Brackets", "Triangle arrows", "Ring + ticks", "Custom image"
        )

        fun fromJson(o: JSONObject) = Config(
            style = o.optInt("style", 0).coerceIn(0, STYLE_NAMES.size - 1),
            sizeDp = o.optInt("size", 60).coerceIn(24, 300),
            thicknessDp = o.optInt("thick", 3).coerceIn(1, 12),
            gapDp = o.optInt("gap", 6).coerceIn(0, 40),
            opacity = o.optInt("opacity", 90).coerceIn(10, 100),
            rotation = o.optInt("rot", 0).coerceIn(0, 359),
            color = o.optInt("color", 0xFFFF2D2D.toInt()),
            dot = o.optBoolean("dot", true),
            dotSizeDp = o.optInt("dotSize", 3).coerceIn(1, 12),
            outline = o.optBoolean("outline", true),
            glow = o.optBoolean("glow", false),
            locked = o.optBoolean("locked", false),
            x = o.optInt("x", 0).coerceIn(-4000, 4000),
            y = o.optInt("y", 0).coerceIn(-4000, 4000),
            imagePath = o.optString("img", ""),
            miniButton = o.optBoolean("mini", false),
            autoPkg = o.optString("auto", "")
        )
    }
}

object Store {
    private const val PREFS = "crosshair_prefs"
    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): Config = try {
        sp(c).getString("current", null)?.let { Config.fromJson(JSONObject(it)) } ?: Config()
    } catch (e: Exception) { Config() }

    fun save(c: Context, cfg: Config) {
        sp(c).edit().putString("current", cfg.toJson().toString()).apply()
    }

    fun presets(c: Context): MutableList<Pair<String, Config>> {
        val out = mutableListOf<Pair<String, Config>>()
        try {
            val arr = JSONArray(sp(c).getString("presets", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += o.getString("name") to Config.fromJson(o.getJSONObject("cfg"))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun writePresets(c: Context, list: List<Pair<String, Config>>) {
        val arr = JSONArray()
        list.forEach { (n, cf) -> arr.put(JSONObject().put("name", n).put("cfg", cf.toJson())) }
        sp(c).edit().putString("presets", arr.toString()).apply()
    }

    fun savePreset(c: Context, name: String, cfg: Config) {
        val list = presets(c).filter { it.first != name }.toMutableList()
        list += name to cfg.copy()
        writePresets(c, list)
    }

    fun deletePreset(c: Context, name: String) {
        writePresets(c, presets(c).filter { it.first != name })
    }

    fun exportPresets(c: Context): String {
        val arr = JSONArray()
        presets(c).forEach { (n, cf) ->
            arr.put(JSONObject().put("name", n).put("cfg", cf.copy(imagePath = "", autoPkg = "").toJson()))
        }
        return arr.toString(2)
    }

    /** Returns number of presets imported. Image paths and game packages are never imported. */
    fun importPresets(c: Context, json: String): Int {
        var n = 0
        try {
            val arr = JSONArray(json)
            val list = presets(c).toMutableList()
            for (i in 0 until minOf(arr.length(), 100)) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name").trim().take(40)
                if (name.isEmpty()) continue
                val cfg = Config.fromJson(o.getJSONObject("cfg")).copy(imagePath = "", autoPkg = "")
                list.removeAll { it.first == name }
                list += name to cfg
                n++
            }
            writePresets(c, list)
        } catch (_: Exception) { }
        return n
    }
}
