package com.vx.crosshair

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.math.min

data class DeviceProfile(
    val model: String,
    val soc: String,
    val androidSdk: Int,
    val abi: String,
    val widthPx: Int,
    val heightPx: Int,
    val densityDpi: Int,
    val diagInches: Double,
    val refreshHz: Float,
    val maxHz: Float,
    val ramMb: Long,
    val lowRam: Boolean,
    val cores: Int,
    val batteryTempC: Float,   // -1 if unknown
    val thermal: String,
    var cpuMs: Long = -1,
    var avgFrameMs: Double = -1.0,
    var jankPct: Double = -1.0
)

object Profiler {

    @Suppress("DEPRECATION")
    fun collect(ctx: Context): DeviceProfile {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        val display = wm.defaultDisplay
        display.getRealMetrics(dm)

        val diag = hypot(
            dm.widthPixels / dm.xdpi.toDouble(),
            dm.heightPixels / dm.ydpi.toDouble()
        )

        val maxHz = display.supportedModes.maxOfOrNull { it.refreshRate } ?: display.refreshRate

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)

        val batt: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = batt?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val tempC = if (t >= 0) t / 10f else -1f

        return DeviceProfile(
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"
            else Build.HARDWARE,
            androidSdk = Build.VERSION.SDK_INT,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
            widthPx = dm.widthPixels,
            heightPx = dm.heightPixels,
            densityDpi = dm.densityDpi,
            diagInches = diag,
            refreshHz = display.refreshRate,
            maxHz = maxHz,
            ramMb = mi.totalMem / (1024 * 1024),
            lowRam = am.isLowRamDevice,
            cores = Runtime.getRuntime().availableProcessors(),
            batteryTempC = tempC,
            thermal = thermalName(ctx)
        )
    }

    private fun thermalName(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 29) return "unknown"
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "light throttling"
            PowerManager.THERMAL_STATUS_MODERATE -> "moderate throttling"
            PowerManager.THERMAL_STATUS_SEVERE -> "severe throttling"
            PowerManager.THERMAL_STATUS_CRITICAL,
            PowerManager.THERMAL_STATUS_EMERGENCY,
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "critical"
            else -> "unknown"
        }
    }

    /** Fixed integer + float workload. Lower ms = faster CPU. Takes the best of 3 runs. */
    fun cpuBenchmarkMs(): Long {
        var best = Long.MAX_VALUE
        repeat(3) {
            val start = System.nanoTime()
            var x = 123456789L
            var f = 0.0
            for (i in 1..6_000_000) {
                x = x xor (x shl 13)
                x = x xor (x ushr 7)
                x = x xor (x shl 17)
                f += (x and 0xFFFF).toDouble() / (i % 97 + 1)
            }
            if (f.isNaN()) throw IllegalStateException("unreachable")
            best = min(best, (System.nanoTime() - start) / 1_000_000)
        }
        return best
    }
}
