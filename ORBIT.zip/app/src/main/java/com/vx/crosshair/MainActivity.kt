package com.vx.crosshair

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var cfg: Config
    private lateinit var btnToggle: Button
    private lateinit var spStyle: Spinner
    private lateinit var tvGame: TextView
    private lateinit var etHex: EditText
    private var ready = false

    private val palette = intArrayOf(
        0xFFFF2D2D.toInt(), 0xFF00E676.toInt(), 0xFF00B0FF.toInt(), 0xFFFFEA00.toInt(),
        0xFFFF9100.toInt(), 0xFFE040FB.toInt(), 0xFFFFFFFF.toInt(), 0xFF00FFFF.toInt()
    )

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importImage(uri)
    }
    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) exportTo(uri) }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFrom(uri)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        cfg = Store.load(this)
        btnToggle = findViewById(R.id.btnToggle)
        spStyle = findViewById(R.id.spStyle)
        tvGame = findViewById(R.id.tvGame)
        etHex = findViewById(R.id.etHex)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        bindStyle()
        bindSeek(R.id.sbSize, R.id.tvSize, "Size", 24, cfg.sizeDp) { cfg.sizeDp = it }
        bindSeek(R.id.sbThick, R.id.tvThick, "Thickness", 1, cfg.thicknessDp) { cfg.thicknessDp = it }
        bindSeek(R.id.sbGap, R.id.tvGap, "Gap", 0, cfg.gapDp) { cfg.gapDp = it }
        bindSeek(R.id.sbDot, R.id.tvDot, "Dot size", 1, cfg.dotSizeDp) { cfg.dotSizeDp = it }
        bindSeek(R.id.sbOpacity, R.id.tvOpacity, "Opacity", 10, cfg.opacity) { cfg.opacity = it }
        bindSeek(R.id.sbRot, R.id.tvRot, "Rotation", 0, cfg.rotation) { cfg.rotation = it }
        bindColors()
        bindCheck(R.id.cbDot, cfg.dot) { cfg.dot = it }
        bindCheck(R.id.cbOutline, cfg.outline) { cfg.outline = it }
        bindCheck(R.id.cbGlow, cfg.glow) { cfg.glow = it }
        bindCheck(R.id.cbLock, cfg.locked) { cfg.locked = it }
        bindCheck(R.id.cbMini, cfg.miniButton) { cfg.miniButton = it }

        etHex.setText("#%06X".format(cfg.color and 0xFFFFFF))
        findViewById<Button>(R.id.btnHex).setOnClickListener { applyHex() }
        findViewById<Button>(R.id.btnImport).setOnClickListener { pickImage.launch(arrayOf("image/*")) }

        findViewById<Button>(R.id.btnLeft).setOnClickListener { nudge(-1, 0) }
        findViewById<Button>(R.id.btnRight).setOnClickListener { nudge(1, 0) }
        findViewById<Button>(R.id.btnUp).setOnClickListener { nudge(0, -1) }
        findViewById<Button>(R.id.btnDown).setOnClickListener { nudge(0, 1) }
        findViewById<Button>(R.id.btnCenter).setOnClickListener {
            cfg.x = 0
            cfg.y = 0
            push(syncPos = false)
        }

        findViewById<Button>(R.id.btnGame).setOnClickListener { pickGame() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { askPresetName() }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportLauncher.launch("crosshair_presets.json") }
        findViewById<Button>(R.id.btnImportPresets).setOnClickListener {
            importLauncher.launch(arrayOf("application/json", "text/plain"))
        }
        btnToggle.setOnClickListener { toggle() }

        updateGameLabel()
        ready = true
        renderPresets()
    }

    override fun onResume() {
        super.onResume()
        cfg = Store.load(this)
        btnToggle.text = if (OverlayService.running) "Stop crosshair" else "Start crosshair"
        updateGameLabel()
    }

    private fun toggle() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (OverlayService.running) {
            OverlayService.send(this, OverlayService.ACTION_STOP)
            btnToggle.text = "Start crosshair"
        } else {
            Store.save(this, cfg)
            OverlayService.send(this, OverlayService.ACTION_START)
            btnToggle.text = "Stop crosshair"
        }
    }

    /** Saves config and refreshes the overlay. syncPos keeps the position the user dragged to. */
    private fun push(syncPos: Boolean = true) {
        if (!ready) return
        if (syncPos) {
            val s = Store.load(this)
            cfg.x = s.x
            cfg.y = s.y
        }
        Store.save(this, cfg)
        if (OverlayService.running) OverlayService.send(this, OverlayService.ACTION_REFRESH)
    }

    private fun nudge(dx: Int, dy: Int) {
        val s = Store.load(this)
        cfg.x = s.x + dx
        cfg.y = s.y + dy
        push(syncPos = false)
    }

    private fun bindStyle() {
        spStyle.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Config.STYLE_NAMES)
        spStyle.setSelection(cfg.style)
        spStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (cfg.style != pos) {
                    if (pos == 8 && cfg.imagePath.isEmpty())
                        Toast.makeText(this@MainActivity, "Import a PNG first", Toast.LENGTH_SHORT).show()
                    cfg.style = pos
                    push()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun bindSeek(sb: Int, tv: Int, label: String, min: Int, value: Int, set: (Int) -> Unit) {
        val bar = findViewById<SeekBar>(sb)
        val txt = findViewById<TextView>(tv)
        bar.progress = (value - min).coerceAtLeast(0)
        txt.text = "$label: $value"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                txt.text = "$label: $v"
                if (fromUser) {
                    set(v)
                    push()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun bindCheck(id: Int, value: Boolean, set: (Boolean) -> Unit) {
        val cb = findViewById<CheckBox>(id)
        cb.isChecked = value
        cb.setOnCheckedChangeListener { _, v ->
            set(v)
            push()
        }
    }

    private fun bindColors() {
        val row = findViewById<LinearLayout>(R.id.colorRow)
        palette.forEach { col ->
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                .apply { setMargins(4, 4, 4, 4) }
            v.setBackgroundColor(col)
            v.setOnClickListener {
                cfg.color = col
                etHex.setText("#%06X".format(col and 0xFFFFFF))
                push()
            }
            row.addView(v)
        }
    }

    private fun applyHex() {
        var t = etHex.text.toString().trim()
        if (!t.startsWith("#")) t = "#$t"
        try {
            cfg.color = Color.parseColor(t) or 0xFF000000.toInt()
            push()
        } catch (e: IllegalArgumentException) {
            Toast.makeText(this, "Use a hex color like #FF2D2D", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IOException("decode failed")
            val f = File(filesDir, "crosshair_${System.currentTimeMillis()}.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (cfg.imagePath.isNotEmpty() && cfg.imagePath != f.absolutePath) File(cfg.imagePath).delete()
            cfg.imagePath = f.absolutePath
            cfg.style = 8
            spStyle.setSelection(8)
            push()
            Toast.makeText(this, "Image imported", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read that image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickGame() {
        if (!OverlayService.hasUsageAccess(this)) {
            Toast.makeText(this, "Turn on Usage access for this app, then come back", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val names = (listOf("Off (always show)") + apps.map { it.first }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Show crosshair only in")
            .setItems(names) { _, which ->
                cfg.autoPkg = if (which == 0) "" else apps[which - 1].second
                updateGameLabel()
                push()
            }
            .show()
    }

    private fun updateGameLabel() {
        tvGame.text = if (cfg.autoPkg.isEmpty()) {
            "Auto-show: off (always visible)"
        } else {
            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(cfg.autoPkg, 0)).toString()
            } catch (_: Exception) {
                cfg.autoPkg
            }
            "Auto-show only in: $label"
        }
    }

    private fun askPresetName() {
        val input = EditText(this)
        input.hint = "Name"
        AlertDialog.Builder(this)
            .setTitle("Save crosshair")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isEmpty()) {
                    Toast.makeText(this, "Name required", Toast.LENGTH_SHORT).show()
                } else {
                    Store.savePreset(this, n, cfg)
                    renderPresets()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportTo(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(Store.exportPresets(this).toByteArray()) }
            Toast.makeText(this, "Presets exported", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importFrom(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: ""
            if (text.length > 1_000_000) throw IOException("too large")
            val n = Store.importPresets(this, text)
            renderPresets()
            Toast.makeText(
                this, if (n > 0) "$n presets imported" else "No presets found in file", Toast.LENGTH_SHORT
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderPresets() {
        val box = findViewById<LinearLayout>(R.id.presetList)
        box.removeAllViews()
        Store.presets(this).forEach { (name, saved) ->
            val btn = Button(this)
            btn.text = name
            btn.setOnClickListener {
                cfg = saved.copy(
                    x = cfg.x, y = cfg.y, autoPkg = cfg.autoPkg, miniButton = cfg.miniButton,
                    imagePath = if (saved.imagePath.isEmpty()) cfg.imagePath else saved.imagePath
                )
                push(syncPos = false)
                recreate()
            }
            btn.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Delete '$name'?")
                    .setPositiveButton("Delete") { _, _ ->
                        Store.deletePreset(this, name)
                        renderPresets()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
            box.addView(btn)
        }
    }
}
