package com.vx.crosshair

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class OptimizerActivity : AppCompatActivity() {

    private lateinit var tvRam: TextView
    private val h = Handler(Looper.getMainLooper())

    private fun memInfo(): ActivityManager.MemoryInfo {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi
    }

    private fun availMb(): Long = memInfo().availMem / (1024 * 1024)
    private fun totalMb(): Long = memInfo().totalMem / (1024 * 1024)

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            Toast.makeText(this, "Not available on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shortcutButton(label: String, action: String): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { openSettings(action) }
        return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val vm = VmCheck.run(this)
        val tvVm = TextView(this)
        tvVm.text = "VMness: ${vm.score}/100 - ${vm.label}\n" + vm.signals.joinToString("\n")
        tvVm.textSize = 13f

        tvRam = TextView(this)
        tvRam.textSize = 15f
        tvRam.setPadding(0, pad, 0, pad / 2)
        updateRam()

        val btnFree = Button(this)
        btnFree.text = "Free background RAM"
        btnFree.setOnClickListener { freeRam() }

        val tips = TextView(this)
        tips.textSize = 13f
        tips.setPadding(0, pad, 0, 0)
        tips.text = if (vm.score >= 50) emulatorTips() else phoneTips()

        root.addView(tvVm)
        root.addView(tvRam)
        root.addView(btnFree, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(shortcutButton("Do Not Disturb access", Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        root.addView(shortcutButton("Battery saver settings", Settings.ACTION_BATTERY_SAVER_SETTINGS))
        root.addView(shortcutButton("Display / refresh rate", Settings.ACTION_DISPLAY_SETTINGS))
        root.addView(shortcutButton("Developer options", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        root.addView(tips)
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    private fun updateRam(note: String = "") {
        tvRam.text = "RAM free: ${availMb()} MB of ${totalMb()} MB $note"
    }

    private fun freeRam() {
        val before = availMb()
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pkgs = packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName }
        var n = 0
        for (p in pkgs) {
            try {
                am.killBackgroundProcesses(p)
                n++
            } catch (_: Exception) { }
        }
        tvRam.text = "Cleaning $n apps..."
        h.postDelayed({
            val after = availMb()
            val sign = if (after >= before) "+" else ""
            updateRam("($sign${after - before} MB). Apps may reload when opened.")
        }, 900)
    }

    private fun phoneTips() = """
        Phone tuning tips
        - Set refresh rate to the highest stable value in Display settings.
        - Turn on Do Not Disturb so calls and pop-ups don't interrupt play.
        - Use the game's own graphics and FPS options; lower them if frames drop.
        - Let the phone cool: remove the case and avoid charging while playing.
        - Developer options: animation scale 0.5x makes the UI feel faster.
    """.trimIndent()

    private fun emulatorTips() = """
        Emulator tuning checklist (menus vary by emulator)
        - Enable virtualization (VT-x / AMD-V) in BIOS; confirm it shows as on in the emulator.
        - Give the emulator 4 CPU cores and 4 GB RAM or more, if your PC has them spare.
        - Try both graphics modes (OpenGL / DirectX / Vulkan) and keep the one with steadier frames.
        - Match the emulator FPS to your monitor refresh rate (60 / 120).
        - Windows: High performance power plan, set the emulator to High performance GPU in Graphics settings.
        - Close browsers and launchers; leave disk space free on the drive holding the emulator.
        - If input feels late, use the Latency Lab here and compare with the emulator's own settings.
    """.trimIndent()
}
