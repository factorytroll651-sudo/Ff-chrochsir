package com.vx.crosshair

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(
    val ts: Long,
    val type: String,
    val title: String,
    val text: String,
    val metrics: Map<String, Double>
)

object HistoryStore {
    private const val PREFS = "history_prefs"
    private const val MAX = 100

    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Newest first. */
    fun all(c: Context): List<HistoryEntry> {
        val out = mutableListOf<HistoryEntry>()
        try {
            val arr = JSONArray(sp(c).getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val m = mutableMapOf<String, Double>()
                val mo = o.optJSONObject("m")
                if (mo != null) {
                    val keys = mo.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        m[k] = mo.optDouble(k)
                    }
                }
                out.add(HistoryEntry(o.getLong("ts"), o.getString("type"), o.getString("title"), o.getString("text"), m))
            }
        } catch (_: Exception) { }
        return out.sortedByDescending { it.ts }
    }

    private fun write(c: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.take(MAX).forEach { e ->
            val m = JSONObject()
            e.metrics.forEach { (k, v) -> if (!v.isNaN()) m.put(k, v) }
            arr.put(
                JSONObject().put("ts", e.ts).put("type", e.type).put("title", e.title)
                    .put("text", e.text).put("m", m)
            )
        }
        sp(c).edit().putString("items", arr.toString()).apply()
    }

    fun add(c: Context, type: String, title: String, text: String, metrics: Map<String, Double>) {
        val list = all(c).toMutableList()
        list.add(0, HistoryEntry(System.currentTimeMillis(), type, title, text, metrics))
        write(c, list)
    }

    fun delete(c: Context, ts: Long) {
        write(c, all(c).filter { it.ts != ts })
    }

    fun clear(c: Context) {
        sp(c).edit().remove("items").apply()
    }
}
