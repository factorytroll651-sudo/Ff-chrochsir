package com.vx.crosshair

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ToggleTile : TileService() {

    companion object {
        fun refresh(c: Context) {
            try {
                TileService.requestListeningState(c, ComponentName(c, ToggleTile::class.java))
            } catch (_: Exception) { }
        }
    }

    override fun onStartListening() = sync()

    override fun onClick() {
        if (!Settings.canDrawOverlays(this)) return
        if (OverlayService.running) OverlayService.send(this, OverlayService.ACTION_STOP)
        else OverlayService.send(this, OverlayService.ACTION_START)
        sync()
    }

    private fun sync() {
        val t = qsTile ?: return
        t.state = if (OverlayService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Crosshair"
        t.updateTile()
    }
}
