package com.vx.crosshair

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build

data class VmResult(val score: Int, val label: String, val signals: List<String>)

/** Tells the user whether this device looks like a real phone or an emulator, so tuning tips can match. */
object VmCheck {

    private val emuNames = listOf(
        "bluestacks", "ldplayer", "nox", "memu", "gameloop", "tiantian",
        "genymotion", "andy", "droid4x", "windroy", "koplayer"
    )

    fun run(ctx: Context): VmResult {
        var score = 0
        val sig = mutableListOf<String>()

        fun hit(w: Int, why: String) {
            score += w
            sig += "+$w  $why"
        }

        val model = Build.MODEL.lowercase()
        val manu = Build.MANUFACTURER.lowercase()
        val brand = Build.BRAND.lowercase()
        val prod = Build.PRODUCT.lowercase()
        val hw = Build.HARDWARE.lowercase()
        val board = Build.BOARD.lowercase()
        val fp = Build.FINGERPRINT.lowercase()

        if (listOf("sdk", "emulator", "android sdk built for").any { model.contains(it) })
            hit(30, "Model name looks like an SDK emulator ($model)")

        val joined = "$model $manu $brand $prod"
        emuNames.firstOrNull { joined.contains(it) }?.let { hit(30, "Known emulator name: $it") }

        if (listOf("goldfish", "ranchu", "vbox86", "ttvm").any { hw.contains(it) || board.contains(it) })
            hit(25, "Virtual hardware ($hw / $board)")

        if (listOf("sdk", "vbox", "emulator", "simulator").any { prod.contains(it) })
            hit(15, "Product name looks virtual ($prod)")

        if (fp.startsWith("generic") || brand.startsWith("generic"))
            hit(15, "Generic build fingerprint")

        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: ""
        if (abi.startsWith("x86")) hit(15, "Primary ABI is $abi (rare on real phones)")

        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        if (sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null)
            hit(10, "No accelerometer")

        val batt: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (batt != null && !batt.getBooleanExtra(BatteryManager.EXTRA_PRESENT, true))
            hit(5, "No battery reported")

        if (sig.isEmpty()) sig += "No virtual-device signals found"

        val s = score.coerceAtMost(100)
        val label = when {
            s < 20 -> "Real device likely"
            s < 50 -> "Uncertain"
            else -> "Emulator / VM likely"
        }
        return VmResult(s, label, sig)
    }
}
