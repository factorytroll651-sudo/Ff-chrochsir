package com.vx.crosshair

import kotlin.math.roundToInt

enum class Tier { LOW, MID, HIGH }

data class Rec(val title: String, val value: String, val why: String)

object Recommender {

    fun tier(p: DeviceProfile): Tier {
        var pts = 0
        pts += when {
            p.ramMb >= 7500 -> 3
            p.ramMb >= 3800 -> 2
            else -> 1
        }
        pts += when {
            p.cpuMs in 0L..130L -> 3
            p.cpuMs in 131L..320L -> 2
            else -> 1
        }
        if (p.cores >= 8) pts += 1
        if (p.lowRam) pts -= 2
        if (p.jankPct > 15.0) pts -= 1
        return when {
            pts >= 6 -> Tier.HIGH
            pts >= 4 -> Tier.MID
            else -> Tier.LOW
        }
    }

    fun recommend(p: DeviceProfile): List<Rec> {
        val t = tier(p)
        val out = mutableListOf<Rec>()

        out += Rec("Device tier", t.name, "From RAM, CPU speed, core count and frame stability.")

        out += when (t) {
            Tier.HIGH -> Rec("Graphics preset", "High / Ultra", "Your CPU and RAM have headroom.")
            Tier.MID -> Rec("Graphics preset", "Medium", "Balances quality against frame drops.")
            Tier.LOW -> Rec("Graphics preset", "Low / Smooth", "Reduces load so frame time stays steady.")
        }

        val fps = when {
            t == Tier.LOW -> 30
            p.maxHz >= 120f && t == Tier.HIGH -> 120
            p.maxHz >= 90f && t != Tier.LOW -> 90
            else -> 60
        }
        out += Rec("FPS cap", "$fps fps", "A cap your phone can hold is smoother than a high one it can't.")

        if (p.maxHz > p.refreshHz + 1f)
            out += Rec(
                "Screen refresh rate", "Set to ${p.maxHz.roundToInt()} Hz",
                "Now ${p.refreshHz.roundToInt()} Hz; your panel supports ${p.maxHz.roundToInt()} Hz in Display settings."
            )

        val hudPct = (100 * 6.5 / p.diagInches).roundToInt().coerceIn(80, 130)
        out += Rec(
            "HUD button size", "$hudPct %",
            "Screen is %.1f in. Smaller screens need relatively larger buttons.".format(p.diagInches)
        )

        out += Rec(
            "HUD opacity", if (p.diagInches < 6.0) "55 %" else "65 %",
            "Lower opacity keeps the scene visible under your thumbs."
        )

        val sens = when (t) {
            Tier.HIGH -> "General 100 / Red dot 95 / Scope 90"
            Tier.MID -> "General 92 / Red dot 88 / Scope 82"
            Tier.LOW -> "General 85 / Red dot 80 / Scope 75"
        }
        out += Rec("Sensitivity (starting point)", sens, "Rough start only. Tune by feel in training mode.")

        if (p.jankPct >= 0)
            out += Rec(
                "Frame stability", "%.1f %% janky frames".format(p.jankPct),
                if (p.jankPct > 15) "High jank: close background apps and lower the preset."
                else "Stable at the current refresh rate."
            )

        if (p.batteryTempC >= 40f || p.thermal.contains("throttling") || p.thermal == "critical")
            out += Rec(
                "Heat", "%.0f C, thermal: %s".format(p.batteryTempC, p.thermal),
                "Let the phone cool, remove the case and avoid charging while playing."
            )

        if (p.ramMb < 4000)
            out += Rec("Background apps", "Close before playing", "Under 4 GB RAM: other apps can force the game to reload.")

        return out
    }

    fun report(p: DeviceProfile): String {
        val sb = StringBuilder()
        sb.appendLine("${p.model} | ${p.soc} | Android SDK ${p.androidSdk} | ${p.abi}")
        sb.appendLine("Screen ${p.widthPx}x${p.heightPx} @ ${p.densityDpi} dpi, %.1f in".format(p.diagInches))
        sb.appendLine("Refresh ${p.refreshHz.roundToInt()} Hz (max ${p.maxHz.roundToInt()} Hz)")
        sb.appendLine("RAM ${p.ramMb} MB, cores ${p.cores}, low-ram flag ${p.lowRam}")
        sb.appendLine("CPU benchmark ${p.cpuMs} ms (lower is faster)")
        sb.appendLine("Frame avg %.2f ms, jank %.1f %%".format(p.avgFrameMs, p.jankPct))
        sb.appendLine()
        recommend(p).forEach { sb.appendLine("${it.title}: ${it.value}\n  ${it.why}") }
        return sb.toString()
    }
}
