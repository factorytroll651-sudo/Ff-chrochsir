package com.vx.crosshair

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_TOGGLE = "toggle"
        const val ACTION_REFRESH = "refresh"
        const val CHANNEL = "crosshair"
        @Volatile var running = false

        fun send(c: Context, action: String) {
            val i = Intent(c, OverlayService::class.java).setAction(action)
            if (action == ACTION_STOP || running) c.startService(i) else c.startForegroundService(i)
        }

        @Suppress("DEPRECATION")
        fun hasUsageAccess(c: Context): Boolean {
            val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val uid = android.os.Process.myUid()
            val mode = if (Build.VERSION.SDK_INT >= 29)
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, uid, c.packageName)
            else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, uid, c.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: CrosshairView? = null
    private var mini: View? = null
    private var cfg = Config()
    private var visible = true          // manual toggle
    private var gameFg = true           // auto-show state
    private var fgPkg: String? = null
    private var firstPoll = true

    private val watcher = object : Runnable {
        override fun run() {
            pollGame()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Crosshair", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (action == ACTION_TOGGLE) {
            visible = !visible
            applyVisibility()
        } else if (action == ACTION_REFRESH) {
            cfg = Store.load(this)
            firstPoll = true
            rebuild()
        } else {
            cfg = Store.load(this)
            goForeground()
            if (view == null) rebuild()
        }
        goForeground()
        running = true
        handler.removeCallbacks(watcher)
        handler.post(watcher)
        return START_STICKY
    }

    private fun goForeground() {
        fun pi(a: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, HubActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val state = when {
            cfg.autoPkg.isNotEmpty() && !gameFg -> "Waiting for game"
            visible -> "Visible"
            else -> "Hidden"
        }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Crosshair active")
            .setContentText(state)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, if (visible) "Hide" else "Show", pi(ACTION_TOGGLE, 1))
            .addAction(0, "Stop", pi(ACTION_STOP, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun pollGame() {
        if (cfg.autoPkg.isEmpty() || !hasUsageAccess(this)) {
            if (!gameFg) { gameFg = true; applyVisibility() }
            return
        }
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (firstPoll) now - 3_600_000 else now - 15_000
            firstPoll = false
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            var last: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
            }
            if (last != null) fgPkg = last
        } catch (_: Exception) { }
        val g = fgPkg == cfg.autoPkg
        if (g != gameFg) { gameFg = g; applyVisibility(); goForeground() }
    }

    private fun active() = cfg.autoPkg.isEmpty() || gameFg

    private fun applyVisibility() {
        view?.visibility = if (visible && active()) View.VISIBLE else View.GONE
        mini?.visibility = if (cfg.miniButton && active()) View.VISIBLE else View.GONE
        ToggleTile.refresh(this)
    }

    private fun rebuild() {
        removeView()
        gameFg = cfg.autoPkg.isEmpty()
        val v = CrosshairView(this, cfg)
        val s = v.sizePx()
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                (if (cfg.locked) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
        val params = WindowManager.LayoutParams(
            s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; x = cfg.x; y = cfg.y }
        if (!cfg.locked) attachDrag(v, params)
        try {
            wm.addView(v, params)
            view = v
            buildMini()
            applyVisibility()
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun attachDrag(v: View, params: WindowManager.LayoutParams) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    params.x = sx + (e.rawX - tx).toInt()
                    params.y = sy + (e.rawY - ty).toInt()
                    try { wm.updateViewLayout(v, params) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP -> {
                    cfg.x = params.x
                    cfg.y = params.y
                    Store.save(this, cfg)
                }
            }
            true
        }
    }

    private fun buildMini() {
        removeMini()
        if (!cfg.miniButton) return
        val d = resources.displayMetrics.density
        val size = (46 * d).toInt()
        val tv = TextView(this).apply {
            text = "✛"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xAA000000.toInt())
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (160 * d).toInt()
        }

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        p.x = sx + dx
                        p.y = sy + dy
                        try { wm.updateViewLayout(tv, p) } catch (_: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        visible = !visible
                        applyVisibility()
                        goForeground()
                    }
                }
            }
            true
        }
        try {
            wm.addView(tv, p)
            mini = tv
        } catch (_: Exception) { }
    }

    private fun removeMini() {
        mini?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        mini = null
    }

    private fun removeView() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        view = null
        removeMini()
    }

    private fun shutdown() {
        handler.removeCallbacks(watcher)
        removeView()
        running = false
        ToggleTile.refresh(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(watcher)
        removeView()
        running = false
        super.onDestroy()
    }
}
