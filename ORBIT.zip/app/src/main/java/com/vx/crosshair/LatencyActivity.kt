package com.vx.crosshair

import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LatencyActivity : AppCompatActivity() {

    private lateinit var pad: TouchPadView
    private lateinit var tvStats: TextView
    private lateinit var tvCut: TextView
    private lateinit var tvBeta: TextView
    private val h = Handler(Looper.getMainLooper())
    private var lastText = ""

    private val tick = object : Runnable {
        override fun run() {
            val s = pad.stats()
            lastText = "Samples: ${s.samples}   Touch rate: ${"%.0f".format(s.hz)} Hz\n" +
                "Interval ms  avg ${"%.1f".format(s.dtAvg)} | p95 ${"%.1f".format(s.dtP95)} | max ${"%.1f".format(s.dtMax)}\n" +
                "Delivery ms  avg ${"%.1f".format(s.deliveryAvg)} | p95 ${"%.1f".format(s.deliveryP95)}\n" +
                "Event to frame ms  avg ${"%.1f".format(s.frameAvg)} | p95 ${"%.1f".format(s.frameP95)}\n" +
                "Jitter px  raw ${"%.2f".format(s.rawJitter)} | smoothed ${"%.2f".format(s.smoothJitter)}\n" +
                "Smoothing lag: ${"%.1f".format(s.lagPx)} px"
            tvStats.text = lastText
            h.postDelayed(this, 400)
        }
    }

    private fun applyCut(p: Int) {
        val v = 0.1 + p / 20.0
        pad.fx.minCutoff = v
        pad.fy.minCutoff = v
        tvCut.text = "Min cutoff: ${"%.2f".format(v)}  (lower = smoother, more lag)"
    }

    private fun applyBeta(p: Int) {
        val v = p / 2000.0
        pad.fx.beta = v
        pad.fy.beta = v
        tvBeta.text = "Beta: ${"%.4f".format(v)}  (higher = less lag on fast moves)"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val pad8 = (8 * d).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad8, pad8, pad8, pad8)

        tvStats = TextView(this)
        tvStats.textSize = 12f
        tvStats.typeface = Typeface.MONOSPACE
        pad = TouchPadView(this)

        tvCut = TextView(this)
        val sbCut = SeekBar(this)
        sbCut.max = 100
        sbCut.progress = 18
        tvBeta = TextView(this)
        val sbBeta = SeekBar(this)
        sbBeta.max = 100
        sbBeta.progress = 20
        applyCut(18)
        applyBeta(20)

        sbCut.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = applyCut(p)
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        sbBeta.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = applyBeta(p)
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val btnClear = Button(this)
        btnClear.text = "Clear"
        val btnCopy = Button(this)
        btnCopy.text = "Copy"
        val btnSave = Button(this)
        btnSave.text = "Save result"
        row.addView(btnClear, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btnCopy, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btnSave, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        btnClear.setOnClickListener { pad.clear() }
        btnCopy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("latency", lastText))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        btnSave.setOnClickListener {
            val s = pad.stats()
            if (s.samples < 20) {
                Toast.makeText(this, "Draw on the pad first", Toast.LENGTH_SHORT).show()
            } else {
                HistoryStore.add(
                    this, "latency", "Latency - ${"%.0f".format(s.hz)} Hz", lastText,
                    mapOf(
                        "hz" to s.hz, "deliveryAvg" to s.deliveryAvg, "frameAvg" to s.frameAvg,
                        "rawJitter" to s.rawJitter, "smoothJitter" to s.smoothJitter, "lagPx" to s.lagPx
                    )
                )
                Toast.makeText(this, "Saved to history", Toast.LENGTH_SHORT).show()
            }
        }

        root.addView(tvStats)
        root.addView(pad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(tvCut)
        root.addView(sbCut)
        root.addView(tvBeta)
        root.addView(sbBeta)
        root.addView(row)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }
}
