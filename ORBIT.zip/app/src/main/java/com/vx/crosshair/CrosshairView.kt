package com.vx.crosshair

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class CrosshairView(ctx: Context, var cfg: Config) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bmp: Bitmap? = null
    private var bmpPath = ""

    init { alpha = cfg.opacity / 100f }

    fun sizePx() = (cfg.sizeDp * d).toInt().coerceAtLeast(24)

    override fun onMeasure(w: Int, h: Int) {
        val s = sizePx()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val s = width.toFloat()
        val cx = s / 2f
        val cy = s / 2f
        val r = s / 2f - cfg.thicknessDp * d
        val t = (cfg.thicknessDp * d).coerceAtLeast(1f)
        val g = cfg.gapDp * d

        c.save()
        c.rotate(cfg.rotation.toFloat(), cx, cy)
        if (cfg.style == 8) {
            drawImage(c, s)
        } else {
            if (cfg.glow) drawAll(c, cx, cy, r, t + 6 * d, g, (cfg.color and 0x00FFFFFF) or 0x55000000)
            if (cfg.outline) drawAll(c, cx, cy, r, t + 2 * d, g, Color.BLACK)
            drawAll(c, cx, cy, r, t, g, cfg.color)
        }
        c.restore()
    }

    private fun drawImage(c: Canvas, s: Float) {
        if (cfg.imagePath != bmpPath) {
            bmpPath = cfg.imagePath
            bmp = if (bmpPath.isEmpty()) null else try {
                BitmapFactory.decodeFile(bmpPath)
            } catch (_: Exception) { null }
        }
        val b = bmp
        if (b == null) {
            // fallback so the user sees something if no image is imported yet
            val cx = s / 2f
            stroke(cfg.color, 3 * d)
            c.drawLine(cx - s / 3, cx, cx + s / 3, cx, p)
            c.drawLine(cx, cx - s / 3, cx, cx + s / 3, p)
            return
        }
        val pad = 2 * d
        val dst = RectF(pad, pad, s - pad, s - pad)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (cfg.glow) {
            paint.colorFilter = PorterDuffColorFilter((cfg.color and 0x00FFFFFF) or 0x55000000, PorterDuff.Mode.SRC_IN)
            val grow = 4 * d
            c.drawBitmap(
                b, null,
                RectF(dst.left - grow / 2, dst.top - grow / 2, dst.right + grow / 2, dst.bottom + grow / 2),
                paint
            )
        }
        paint.colorFilter = PorterDuffColorFilter(cfg.color, PorterDuff.Mode.SRC_IN)
        c.drawBitmap(b, null, dst, paint)
    }

    private fun stroke(color: Int, w: Float, fill: Boolean = false) {
        p.reset(); p.isAntiAlias = true; p.color = color
        p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE
        p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
    }

    private fun drawAll(c: Canvas, cx: Float, cy: Float, r: Float, t: Float, g: Float, col: Int) {
        stroke(col, t)
        when (cfg.style) {
            0 -> {
                c.drawLine(cx - r, cy, cx + r, cy, p)
                c.drawLine(cx, cy - r, cx, cy + r, p)
            }
            1 -> {
                c.drawLine(cx - r, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + r, cy, p)
                c.drawLine(cx, cy - r, cx, cy - g, p); c.drawLine(cx, cy + g, cx, cy + r, p)
            }
            2, 3 -> c.drawCircle(cx, cy, r, p)
            4 -> {
                val k = r * 0.7f
                c.drawLine(cx - k, cy - k, cx + k, cy + k, p)
                c.drawLine(cx + k, cy - k, cx - k, cy + k, p)
            }
            5 -> {
                val a = r * 0.45f
                c.drawLine(cx - r, cy - r, cx - r + a, cy - r, p); c.drawLine(cx - r, cy - r, cx - r, cy - r + a, p)
                c.drawLine(cx + r, cy - r, cx + r - a, cy - r, p); c.drawLine(cx + r, cy - r, cx + r, cy - r + a, p)
                c.drawLine(cx - r, cy + r, cx - r + a, cy + r, p); c.drawLine(cx - r, cy + r, cx - r, cy + r - a, p)
                c.drawLine(cx + r, cy + r, cx + r - a, cy + r, p); c.drawLine(cx + r, cy + r, cx + r, cy + r - a, p)
            }
            6 -> {
                stroke(col, t, fill = true)
                for (i in 0 until 4) {
                    val ang = Math.toRadians(i * 90.0 - 90)
                    val tipX = cx + (r * cos(ang)).toFloat()
                    val tipY = cy + (r * sin(ang)).toFloat()
                    val base = r * 0.55f
                    val bx = cx + (base * cos(ang)).toFloat()
                    val by = cy + (base * sin(ang)).toFloat()
                    val nx = (-sin(ang)).toFloat()
                    val ny = cos(ang).toFloat()
                    val w = r * 0.12f
                    val path = Path().apply {
                        moveTo(tipX, tipY)
                        lineTo(bx + nx * w, by + ny * w)
                        lineTo(bx - nx * w, by - ny * w)
                        close()
                    }
                    c.drawPath(path, p)
                }
                stroke(col, t)
                c.drawCircle(cx, cy, g.coerceAtMost(r * 0.5f), p)
            }
            7 -> {
                c.drawCircle(cx, cy, r, p)
                for (i in 0 until 4) {
                    val ang = Math.toRadians(i * 90.0)
                    c.drawLine(
                        cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat(),
                        cx + ((r - 10 * d) * cos(ang)).toFloat(), cy + ((r - 10 * d) * sin(ang)).toFloat(), p
                    )
                }
            }
        }
        if (cfg.dot) {
            stroke(col, t, fill = true)
            val extra = if (t > cfg.thicknessDp * d + 1f) 3 * d else 0f
            c.drawCircle(cx, cy, (cfg.dotSizeDp * d).coerceAtLeast(1f) + extra, p)
        }
    }
}
